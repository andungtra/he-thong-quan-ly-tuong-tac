package org.hcmus.tis.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = Account.class)
public class AccountIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
