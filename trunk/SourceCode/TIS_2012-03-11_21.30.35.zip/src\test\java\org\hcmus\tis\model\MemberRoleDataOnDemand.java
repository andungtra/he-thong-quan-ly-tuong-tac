package org.hcmus.tis.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = MemberRole.class)
public class MemberRoleDataOnDemand {
}
