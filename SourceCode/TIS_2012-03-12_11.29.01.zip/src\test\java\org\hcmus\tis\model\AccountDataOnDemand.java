package org.hcmus.tis.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Account.class)
public class AccountDataOnDemand {
}
