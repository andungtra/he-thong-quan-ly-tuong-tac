package org.hcmus.tis.model;

import org.junit.Test;
import org.springframework.roo.addon.test.RooIntegrationTest;

@RooIntegrationTest(entity = MemberRole.class)
public class MemberRoleIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
