package org.hcmus.tis.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = StudyClass.class)
public class StudyClassDataOnDemand {
}
