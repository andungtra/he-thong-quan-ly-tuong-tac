package org.hcmus.tis.model;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Project.class)
public class ProjectDataOnDemand {
}
